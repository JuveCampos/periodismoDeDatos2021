# Gráficas en plotly
# Autor: Jorge Juvenal Campos Ferreira
# Ejercicio 06 sin resolver ----

# Opciones
Sys.setlocale("LC_ALL", "es_ES.UTF-8") #mac
# Sys.setlocale("LC_ALL", "Spanish") #windows/linux

# Librerias ----
library(pacman)
p_load(tidyverse, 
       plotly, 
       readxl, 
       scales)

# BASES DE DATOS ----
bd <- read_xlsx("01_Datos/TweetsGobernadores.xlsx")
btc <- read_csv("01_Datos/BTC-USD.csv")

# Replicar una de las tres gráficas de la carpeta "Replicar"

# PISTA: Paleta de colores: (puede ser fill o color, dependiendo de la grafica)
# scale_fill_manual(values = c("pink", 
#                              "orange", 
#                              "brown", 
#                              "blue", 
#                              "purple", 
#                              "yellow", 
#                              "red", 
#                              "green"))
# scale_color_manual(values = c("pink", 
#                              "orange", 
#                              "brown", 
#                              "blue", 
#                              "purple", 
#                              "yellow", 
#                              "red", 
#                              "green"))

