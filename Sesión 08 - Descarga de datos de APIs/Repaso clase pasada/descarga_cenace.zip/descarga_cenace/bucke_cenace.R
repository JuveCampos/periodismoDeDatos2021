library(tidyverse)
library(curl)

archivos <- read_csv("Copia de 2021.csv")

# Caso n = 1
curl_download(url = archivos$destinos[1],
              destfile = "archivos_cenace/archivo_1.csv")

# Sustituir la parte variable con un objeto de R
i <- 3
curl_download(url = archivos$destinos[i],
              destfile = str_c("archivos_cenace/archivo_",i,".csv"))

# Genero el bucle

for (i in 1:184){
  print(i)
  curl_download(url = archivos$destinos[i],
                destfile = str_c("archivos_cenace/archivo_",i,".csv"))
}


